# Deploying the Georgia Civil website

Your site is plain HTML/CSS/JS — no build step, no server code. That makes it cheap (free, in
fact) and fast to put online. Below is the simplest path first, then alternatives.

---

## Option A — Netlify drag-and-drop (recommended, ~5 minutes, free)

This is the fastest way to get a live URL.

1. Go to **https://app.netlify.com/drop** (create a free account if prompted).
2. **Drag the entire `gci-site` folder** onto the page.
3. Wait a few seconds. Netlify gives you a live URL like
   `https://random-name-12345.netlify.app`. **Your site is now live.**
4. In **Site configuration → Change site name**, rename it to something like
   `georgia-civil` → `https://georgia-civil.netlify.app`.

To update the site later, drag the folder onto the same site again (Deploys tab → drag), or
connect it to GitHub (Option B) for automatic updates.

### Your contact form already works on Netlify
The form in `contact.html` is wired for **Netlify Forms** (it has `name="contact"`,
`data-netlify="true"`, and a spam honeypot). As soon as you deploy to Netlify:
- Submissions appear under **Forms** in your Netlify dashboard.
- Turn on email notifications: **Forms → Settings & notifications → add notification → email**,
  and send them to your team's inbox.
No server, no code — Netlify handles it. (On any other host the form won't collect submissions
unless you wire up a form service; see the note at the bottom.)

---

## Option B — GitHub + Netlify (best if you'll update often)

1. Create a free GitHub account and a new repository (e.g. `gci-website`).
2. Upload the contents of `gci-site` to the repo (GitHub's web "Add file → Upload files"
   works fine — upload the files and the `assets` folder).
3. In Netlify: **Add new site → Import from Git → pick the repo.** Leave build command blank
   and publish directory as `/` (root). Deploy.
4. Now every time you push a change to GitHub, Netlify redeploys automatically.

---

## Option C — GitHub Pages (free, no Netlify)

1. Create a repo and upload the files (as in Option B, steps 1–2).
2. Repo **Settings → Pages → Source: Deploy from a branch → `main` / root → Save.**
3. Your site appears at `https://yourusername.github.io/repo-name/` in a minute or two.

Note: GitHub Pages has **no built-in form handling**, so the contact form would need a form
service (see bottom note).

## Option D — Vercel (free, similar to Netlify)
Sign up at vercel.com, **Add New → Project**, import the GitHub repo (no framework, root
directory), deploy. Good if you later grow the site into something more dynamic.

---

## Pointing your own domain (e.g. georgiacivil.com)

Once the site is live on a `.netlify.app` (or other) URL:

1. **Buy the domain** if you don't own it (Namecheap, Google/Squarespace Domains, GoDaddy, etc.).
2. In Netlify: **Domain management → Add a domain →** enter your domain.
3. Netlify shows you what DNS records to set. Easiest option: change your domain's
   **nameservers** to Netlify's (they'll list them), which lets Netlify manage everything.
   Alternatively add the records they specify at your current registrar (an `A`/`ALIAS` record
   for the root and a `CNAME` for `www`).
4. DNS changes can take anywhere from a few minutes to a few hours to propagate.
5. **HTTPS** (the padlock) is automatic and free — Netlify issues an SSL certificate once the
   domain is verified. Leave "Force HTTPS" on.

The same general steps apply on Vercel; GitHub Pages supports custom domains too (Settings →
Pages → Custom domain) with a similar DNS setup.

---

## After you're live — a quick checklist

- Replace the placeholder logo, photos, leadership details, and LinkedIn URL (see README.md).
- Test the contact form by submitting it once and confirming it lands in your inbox.
- Open the site on your phone — it's already responsive, but check your real content fits.
- Optional: add a `favicon` (your monogram) and set up Netlify's free analytics if you want
  traffic stats.

---

## Note: live LinkedIn news feed

The "News / From the field" sections are static cards linking to LinkedIn. A genuinely
auto-updating LinkedIn feed can't run on a pure static site — LinkedIn has no free public feed
API for this, so it requires either a small backend or a paid third-party embed widget
(e.g. EmbedSocial, Elfsight, Taggbox). If you want that later, it's an add-on; for now the
static cards look clean and need zero upkeep — just edit the headlines in the HTML when you
have news, or update the links to point at specific posts.

## Note: contact form on non-Netlify hosts

If you deploy somewhere **other than Netlify**, the form needs a form-handling service to
actually deliver submissions. The easiest is **Formspree** (free tier): create a form, then in
`contact.html` change the `<form>` tag's `action` to your Formspree endpoint and remove the
`data-netlify` attribute. Squarespace/Wix-style hosts have their own form blocks instead.
