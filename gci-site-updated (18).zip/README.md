# Georgia Civil — Website

A complete, deployable static marketing site for Georgia Civil (GCI), built from your
Brand ID, page descriptions, and pitch scripts.

---

## What's here

```
gci-site/
├── index.html              Landing (hero carousel, pitch, division flip cards, news)
├── why-gci.html            Why GCI (v3 "Built on Better Planning" narrative)
├── land-planning.html      Land Planning division
├── land-surveying.html     Land Surveying + LiDAR / Staking / ALTA boxes
├── civil-engineering.html  Civil Engineering (SiteOps, Camp Buckhead)
├── project-spotlight.html  Project grid
├── join-our-team.html      Careers / culture
├── contact.html            Leadership + contact form (hidden page)
├── lidar.html              Surveying detail (hidden)
├── construction-staking.html  Surveying detail (hidden)
├── alta-surveys.html       Surveying detail (hidden)
├── project-bana-85.html    Project detail template (hidden)
└── assets/
    ├── css/styles.css      The whole brand system (colors, type, components)
    ├── js/main.js          Shared header/footer, hero carousel, mobile nav
    └── img/                Logo + decorative SVGs
```

Open `index.html` in any browser to preview locally. To go live, see **DEPLOYMENT.md**.

---

## The brand system, applied

- **Colors** (exact hex from your Brand ID): Dark Blue `#020534`, Georgia Red `#CA2131`,
  Warm Brass `#B18750`, Gray `#787878`. Buttons, link hover (red), and active (brass)
  follow your web-design spec.
- **Type roles**: H1/H2 in a condensed serif (your "Times New Roman MT Condensed"),
  body in Montserrat (your "Solomon Sans"), nav/labels in Roboto all-caps with
  letter-spacing `0.139em`. See the substitution note below.
- **Signature motif**: topographic contour linework — the same survey/site-plan lines that
  are your work product and your secondary Georgia logo. It runs through the hero and the
  interior page headers. This intentionally avoids the generic corporate stock photography
  your Brand ID says to avoid.
- Your three web-graphics (winding road, contour field, city skyline) are recreated as SVGs
  in `assets/img/` and used as section accents.

---

## Things to replace before / after launch

Everything below is a clearly-marked placeholder. None of it blocks deploying — you can
launch first and swap as you go.

1. **Logo** — your white "gc / georgia civil" logo is in place at `assets/img/logo.png`, shown
   top-left in the header and bottom-left in the footer. To swap it (e.g. a different color
   variant or a higher-resolution file), just replace that file — keep it white/transparent so it
   reads on the dark blue bar, or update the CSS background if you use a dark-on-light version.

2. **Photography** — these are now in place: the **landing hero carousel** (Morgan Medical
   Center and Farmview Market, Madison GA) and the three **division flip cards** (gazebo →
   Land Planning, survey crew → Land Surveying, construction aerial → Civil Engineering).

   Still needed — the four **project photos**, which appear on each project page and as the
   Project Spotlight thumbnails. Drop these into `assets/img/` using these **exact names**
   (until then you'll see a brand-blue placeholder labeled with the intended shot):

   | File (`assets/img/…`)             | Used on                               | Suggested size       |
   |-----------------------------------|---------------------------------------|----------------------|
   | `project-bana-85.jpg`             | Bana 85 page + spotlight thumbnail     | ~1600×1000 landscape |
   | `project-prowell-park.jpg`        | Prowell Park page + spotlight thumbnail| ~1600×1000 landscape |
   | `project-morgan-county-park.jpg`  | Morgan County Park page + thumbnail    | ~1600×1000 landscape |
   | `project-camp-buckhead.jpg`       | Camp Buckhead page + thumbnail         | ~1600×1000 landscape |

   Also optional: `leader-1.jpg` / `leader-2.jpg` for the Contact page headshots (~800×1000
   portrait). Match your photography standards (survey crews, drones, construction, site plans,
   Georgia landscapes — not generic stock). Nothing breaks if a file is missing.

3. **Leadership** — `contact.html` has placeholder principals ("First Last, PE / RLS") with
   dummy phone/email. Replace with real names, credentials, photos, and contact details.

4. **LinkedIn URL** — the footer and news cards point to `https://www.linkedin.com/`. Replace
   with your real company page URL (search `linkedin.com` across the files).

5. **News section** — currently static cards that link to LinkedIn. A *live* auto-synced feed
   isn't possible on a pure static site (it needs a backend or a third-party widget) — see the
   note in DEPLOYMENT.md. The static cards are a clean, zero-maintenance stand-in.

6. **Project pages** — all four spotlight projects now have their own pages
   (`project-bana-85.html`, `project-prowell-park.html`, `project-morgan-county-park.html`,
   `project-camp-buckhead.html`), each with a tailored "reach out if your project is similar"
   call-to-action at the bottom. To add a new project later, copy any of these files, update the
   copy, drop a `project-<name>.jpg` in `assets/img/`, and add a row to `project-spotlight.html`.

---

## Editing tips

- **Header/footer/nav** live in ONE place: the `NAV`, `MONO`, and build functions in
  `assets/js/main.js`. Change a nav label once and it updates on all 12 pages.
- **Colors and type** are CSS variables at the top of `assets/css/styles.css` (`:root`).
- The current heading font is your universally-installed **Times New Roman**, slightly
  condensed via CSS to match your monogram. If you license the real **Times New Roman MT
  Condensed** (and **Solomon Sans** for body), add the `@font-face` rules and change
  `--display` / `--body` in `:root` — nothing else needs to change.

---

## Note on "Built on Better Planning"

Every brand document uses **"Built on Better Planning"** (which is also grammatically correct),
so that's what's on the site. Your message said "Built **by** Better Planning." If you do want
"by," it's a one-word find-and-replace across the files.
